package com.example.gramswaraj;

public class ClickedItemActivity {
}
