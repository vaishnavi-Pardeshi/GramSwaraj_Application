package com.example.gramswaraj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView leftIcon=findViewById(R.id.left_icon);
        ImageView RightIcon=findViewById(R.id.right_icon);
        TextView title=findViewById(R.id.toolbar_title);

        

        leftIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"You Clicked in left icon ",Toast.LENGTH_SHORT).show();
            }
        });

        RightIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_menu();
            }
        });

    }

    public void open_menu()
    {
        Intent i1=new Intent(this,MainActivity2.class);
        startActivity(i1);
    }
}