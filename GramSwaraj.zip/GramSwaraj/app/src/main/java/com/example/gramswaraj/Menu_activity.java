package com.example.gramswaraj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Menu_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu2);
    }
}